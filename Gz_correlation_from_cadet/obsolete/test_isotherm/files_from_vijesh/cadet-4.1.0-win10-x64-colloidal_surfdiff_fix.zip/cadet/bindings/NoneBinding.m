
classdef NoneBinding < BindingModel
	%NoneBinding A binding model that does nothing
	%
	% See also BINDINGMODEL

	% Copyright: (C) 2008-2021 The CADET Authors
	%            See the license note at the end of the file.

	properties(Constant)
		name = 'NONE'; % Name of the binding model according to CADET file format specs
	end

	methods

		function obj = NoneBinding()
			%NONEBINDING Constructs a NoneBinding object
		end

		function res = validate(obj, nComponents, nBoundStates)
			%VALIDATE Validates the binding model parameters
			%   RES = VALIDATE(NCOMPONENTS, NBOUNDSTATES) uses the number of
			%   components NCOMPONENTS of the model and the number of bound
			%   states of each of these components as given by the vector
			%   NBOUNDSTATES to validate the parameters of the binding model.
			%   Returns true in RES if everything is fine and false otherwise.

			res = true;
		end

	end

	methods (Static)

		function obj = loadobj(S)
			if isstruct(S)
				obj = NoneBinding();
				obj.loadobjInternal(S);
			end
		end
		
	end

end

% =============================================================================
%  CADET
%  
%  Copyright (C) 2008-2021: The CADET Authors
%            Please see the AUTHORS and CONTRIBUTORS file.
%  
%  All rights reserved. obj program and the accompanying materials
%  are made available under the terms of the GNU Public License v3.0 (or, at
%  your option, any later version) which accompanies obj distribution, and
%  is available at http://www.gnu.org/licenses/gpl.html
% =============================================================================
