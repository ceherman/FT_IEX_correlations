# Examples

## forward

Contains examples that demonstrate how to set up a pure forward simulation without sensitivities.
The examples focus on how to create and combine the different classes.

## techniques

These examples demonstrate different techniques and more complicated simulations.

## parest

Exemplifies the use of the ParameterFit class and its features.

## publications

Provides the code of different publications using CADET.
